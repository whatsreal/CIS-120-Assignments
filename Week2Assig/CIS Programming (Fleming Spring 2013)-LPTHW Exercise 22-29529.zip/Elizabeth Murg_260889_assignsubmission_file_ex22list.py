#Elizabeth Murg
# Assignment Number 22. 2/10/2014

# (pound sign): will create a comment, nothing after it will be read
print: prints whatever is after it
"" (double quotes): create strings will print what's inside if there's a print 
_ (underscore): can function as a space 
= (equals): will show that something is the same (equal to something else) or can also assign
\t : will make a tab in strings
\n : will make a new line in strings
\\ : will add a slash
''' (triple single quotes): you can write a string that's as many lines long as you'd like it to be.
%s : string format character
% : shows what you want inputted to the format characters in strings
%r : will print exactly as it is written (format character)
'' : make a string
() : list of items 
\' : will make the ' character show up in strings
\" : will make the " character show up in strings
, : separate list items
raw_input: let's the user input something like integers or words
from: tells the computer to takes something from (import)
sys: sys module
import: tell functions to import 
argv: unpacks arguments
""": will let you write a string as many lines as you want it.
open: will open a file and you can write to the file using 'w'
read: will read what's in the file as a string
readline: will read one line from file
readlines: will read all lines from file 
write: write stuff to the file
close: close the file
truncate: delete everythingn in the file
def: make a new function
: : shows that the end of function definiton
+ (plus): add things or using for cat
seek: like a rewind; moves to a place in the file 
+= : variable = variable + number
return: shows what the function will give back
- (minus): subtract numbers
* (multiply): multiply numbers
/ (divide): divide numbers
%d (percent d): format character like percent s but for numbers
< (less than): less-than 
> (greater than): greater-than 
>= (greater or equal to): greater-or-equal-to 
<= (less or equal to): less-or-equal-to 
True:  boolean 
False:  boolean 