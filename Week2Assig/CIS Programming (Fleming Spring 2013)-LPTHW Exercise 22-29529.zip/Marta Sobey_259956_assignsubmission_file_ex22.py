#Marta Sobey
#Assignment Number 22. 2/10/14

print - prints what ever follows it into shell
# is used to comment while coding
+ addition
- subtraction
/ division (forward slash)
* multiplication
% module (remainder)
> greater than
< less than
>= greater or equal to
<= less than or equal to
variables allow you to assigns strings or numbers to one word of phrase.
%r is replaced by a variable's exact content
%d is used for digits
%s is used for digits and strings
= is used to assign a variable to a value
== is used to compare to things equality
True is the output when a statement is true
False is the output when a statement is false
a , after one line which is followed by more content that is on a different line tells the two lines to print directly after each other on the same line
'' and "" are used to surround strings
""" or ''' is used to surround a long string that is on different lines.
\n is an escape sequence to tell a code to start a new line
\t is an escape sequence for tab
\\ is used when you want \ to appear
\b is a space
\ is used to escape out of quotes so you can have quotes within quotes
raw_input is used when you want the user to interact directly with the program
from sys import argv is used to import information from different locations into your file
= argv is a way to define which arguments you will be using in that file
open() opens a specified file
.read is means open a file to read
truncate deals with the size of the file
.write opens a file to write
close() closes a file
'w' opens a file to allow writing
def defines a function