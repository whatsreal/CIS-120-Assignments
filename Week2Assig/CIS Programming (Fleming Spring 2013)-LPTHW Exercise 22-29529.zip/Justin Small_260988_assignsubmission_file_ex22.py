# Justin Small, Excersise 22, 2/10/2014

# print -- outputs a string"
# "" -- contains a string
# '' -- contains a string
# # -- comments out a line
# + -- plus
# - -- minus
# / -- divides
# * -- multiply
# % -- percent
# < -- less than
# > -- greater than
# <= -- less than or equal
# >= -- greater than or equal
# abcdefghijklmnopqrstuvwxyz -- characters
# 1234567890 -- integers
# = -- assign a variable 
# 4.0 -- floating point number
# _ -- underscore character
# %r -- debug script
# %s -- display to user
# raw_input -- takes input from the user
# argv -- arguement variable from command line
# import -- adds a module 

