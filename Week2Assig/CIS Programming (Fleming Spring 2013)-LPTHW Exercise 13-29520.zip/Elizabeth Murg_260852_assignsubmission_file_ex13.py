#Elizabeth Murg
#Assignment Number 13. 2/5/2014.

#this line will tell the Python which plan to use
#from sys import argv

#argv stands for argument variable and it shows and holds the arguments you plan to use in the script
#thus, line 9 will unpack the arguments held by argv
#script, first, second, third = argv

#this block will just print them normally
#print "The script is called:", script
#print "Your first variable is:", first
#print "Your second variable is:", second
#print "Your third variable is:", third

#if you give fewer than three arguments Python won't know what to unpack because you specified three arguments in argv

#script with fewer arguments (does the same thing as the first time except with fewer arguments)
#from sys import argv

#script, banana, potato = argv

#print "The script is called:", script
#print "Minions love to eat:", banana
#print "They do not like the:", potato

#script with more arguments (does the same thing as the first time around except with more arg)
#from sys import argv

#script, Marta, Betty, food, TIU = argv

#print "The script is called:", script
#print "The Mathematics Secondary Ed major is:", Marta
#print "The girl with the red hat is:", Betty 
#print "I love to eat:", food
#print "The college they attend is:", TIU

#combining argv with raw_input not sure how to do that actually









#I commented out the previous two examples using argv because they don't all work at the same time.