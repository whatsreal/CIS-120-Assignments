# Justin Small, Excersise 13, 2/8/2014 "Check in the computer lab"

#from sys import argv

#script, first, second, third = argv

#print "The script is called:", script
#print "Your first variable is:", first
#print "Your second variable is:", second
#print "Your third variable is:", third



#Study Drills 
#1. The first error happens because there are not enough arguments for argv to work.


#2. 
#from sys import argv

#script, foot, smell = argv

#print "The script is called:", script
#print "Your foot is:", foot
#print "Your smell is:", smell

#from sys import argv

#script, fruit, mud, burn, chives = argv

#print "The script is called:", script
#print "Your fruit is:", fruit
#print "Your mud is:", mud
#print "Your burn is:", burn
#print "Your chives is:", chives


#3.
from sys import argv

script, name = argv

print "Hello %s, my name is Jim. What is your favorite gnome?" % name
gnome = raw_input()

print "Wow %s, I think %s is lame" % (name, gnome)



#4. Awesome :)