# Justin Small, Excersise 11, 2//8/2014

#print "How old are you?",
#age = raw_input()
#print "How tall are you?",
#height = raw_input()
#print "How much do you weigh?",
#weight = raw_input()

#print "So, you're %r old, %r tall and %r heavy." % (
#    age, height, weight)

print "What is the cheif end of man?",
man = raw_input()
print "What is philosophy?",
philosophy = raw_input()
print "Who lives in a pineapple under the sea?",
pineapple = raw_input()

print "So, the cheif end of man is %r, philosophy is %r, and %r lives in a pineapple under the sea." % (man, philosophy, pineapple)
