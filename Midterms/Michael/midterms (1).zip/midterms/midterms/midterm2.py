import shelve
import string
from sys import exit

class phoneentry:	
    def __repr__(self):
            return('%s:%d' % ( self.name, self.type ))
			
    def __init__(self, name, number, work, relation):
        self.name = name;
        self.number = number;
        self.work = work;
        self.relation = relation;

    def __cmp__(self, that):
            this = string.lower(str(self))
            that = string.lower(that)

            if string.find(this, that) >= 0:
                    return(0)
            return(cmp(this, that))

    def showtype(self):
            if self.type == number: return('Number')
            if self.type == name: return('Name')
            if self.type == work: return('Work')
            if self.type == relation: return('Relation')

class phonebook:
	def __init__(self, dbname = 'phonedata'):
		self.dbname = dbname;
		self.shelve = shelve.open(self.dbname);
		self.phonedata = []

	def __del__(self):
		self.shelve.close()
		self.shelve = None
	
	def add(self, name, number, work, relation):
		self.phonedata.append(phoneentry( name, number, work, relation))


	def search(self, string):
		for sublist in self.phonedata:
			print sublist;


def openPB():
	foo = phonebook()
	print 'Please select an option:'
	print '1 - Lookup'
	print '2 - Add'
	print '3 - Delete'
	print '4 - Quit'
	entry=int(raw_input('>> '))
	if entry==1:
		namesearch=raw_input('Please enter a name: ')
		foo.search(namesearch)

	elif entry==2:
		name=raw_input('Name: ')
		number=raw_input('Number: ')
		work=raw_input('Work: ')
		relation=raw_input('Relation: ')
		foo.add(name, number, work, relation)
	elif entry==3:
		delname=raw_input('Please enter a name to delete: ')
		print "Contact '%s' has been deleted" (delname)
	elif entry==4:
		print "Phone book is now closed"
		exit(4)
	else:
		print "Your entry was not recognized."
		openPB()
i = phonebook
while (i):
	i = phonebook
	openPB()