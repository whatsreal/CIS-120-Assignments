#Finger Exercise 6
#Chapter 4 Secition 1.1

"""Write a function isIn that accepts two strings as arguments and returns True if either 
string occurs anywhere in the other, and False otherwise. Hint: you might want to use
the built-in str operation "in" """

#Research str.in online, find out how it works.

#define the function here:




#test the function here: