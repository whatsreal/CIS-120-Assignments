#Finger Exercise 3
#End of Chapter 2 Section 4

#Write a program that gets 10 integers from the user.
#Compare those variables and find the largest odd number.
#Print that number or an error message saying that there were none.


#Get the 10 variables. 
#Can you use a for-loop (or a while-loop) and list?





#Compare the variables.  Remember the previous FE.  It only had 3 variables.
#This may be far more complex if you do it the same way.  Can you simplify the logic any?






























#Hint keep a record of the largest odd variable you've come across and only compare against that.
#Use a loop.