#Finger exercise 5
#Chapter 3 Section 2

"""Let s be a string that contains a sequence of decimal numbers separated by commas. 
Write a program that prints the sum of the numbers in s."

#Create s as a string of numbers with decimals separated by commas
s = ""

#Write a function that accepts a string and returns a list of floating point numbers
#Hint: we know a function that splits strings on any character.


#Write a function that adds up all the elements in the list.
#Make sure to explicitly cast the list items as floating point numbers: float(<number here>) 