#Finger Exercise 6
#Chapter 7 Secition 2

"""Implement a function that meets the specification below.
"""

def findAnEven(l):
    """Assumes l is a list of integers.
       Returns the first even number in l.
       Rises ValueError if l does not contain an even number."""
       
#You will need to review exceptions.
#Use a try except block to raise the error.