#Finger Exercise 1
#End of Chapter 1

#Write out instructions to get from one place to another.
#You can pick the two places, make it like you're telling someone who has never been before.
#Put them here:






#Now, imagine that the person following them does exactly what is in the instructions.
#They can do nothing more and nothing less.  They are over-literal what problems will they have?

