#Finger Exercise 6
#Chapter 4 Secition 1.1

"""Implement a function that meets the specification below. Use a try-except block.
"""

def sumDigits(s):
	"""Assumes s is a string
	Returns the sum of the decimal digits in s
	For example, if s is 'a2b3c' it returns 5"""