#Finger Exercise 6
#Chapter 3 Section 4

#What is the decimal equivalent of the binary number 10011