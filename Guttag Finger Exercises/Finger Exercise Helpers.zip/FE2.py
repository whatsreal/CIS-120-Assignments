#Finger Exercise 2
#End of Chapter 2 Section 2

#Write a program that examines three variables x, y, and z.
#It prints the largest odd variable of the three.
#If none of the variables are odd print an error message.



#Define the three variables:




#Use nested if-elif-else statements to find the largest odd number.
#What if all the numbers are odd?
#What if only 1 is odd? Or 2?
#What if the largest number is even, but one of the others is odd?
#Account for all possibilities in the if statement.  (It might be kinda big.)