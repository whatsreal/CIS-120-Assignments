#Finger Exercise 4
#End of Chapter 3 Section 1

#Write a program that accepts an integer for input from the user.
#Find two integers pwr and root where root**pwr equals the integer entered by the user.
#pwr can be no greater than 6



#Get the integer from the user:
#Be sure to convert/cast it as an integer in case the user enters something funky.



#Write a while or for-loop (or more than one, maybe you'll need nested loops!)
#Check each possible power (0-6) against all numbers that root could be.
#How will you know when to stop your checks?






#Print the variables if root**pwr exactly matches the integer entered by the user.
#otherwise print an error message.