#Marta Sobey 
#Assignment Number 42. 2/24/14

#tech blog says, "Nose will look for all the test like files when you run it and call the matching functions in the code base, calculate their coverage etc."
#python says that "The doctest module searches for pieces of text that look like interactive Python sessions, and then executes those sessions to verify that they work exactly as shown."

class Room(object):

	def __init__(self, name, description):
		self.name = name
		self.description = description
		self.paths = {}
		self.marta = "sobey"
	def go(self, direction):
		return self.paths.get(direction, None)

	def add_paths(self, paths):
		self.paths.update(paths)
		