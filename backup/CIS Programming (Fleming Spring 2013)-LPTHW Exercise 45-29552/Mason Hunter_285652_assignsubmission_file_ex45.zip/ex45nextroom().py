#Mason Hunter CIS120
#Assignment 45
def next_room():
    Answer = raw_input("What do you do? >")
    if answer == correct_answer
        return go_on