#Mason Hunter CIS 120
#Assignment 45
from ex45nextroom import *
from sys import exit
class room(object):
    def __init__(self, fight, flee):
        self.name = None
        self.fight = fight
        self.flee = flee
class basement(room):
    def __init__(self, fight, flee):
        self.name = None
        self.fight = fight_outcome
        self.flee = flee_outcome
    def fight():
        global correct_answer
        return correct_answer
    def flee():
        global correct_answer
        return correct_answer
class first_floor(room):
    def __init__(self, fight, flee):
        self.name = None
        self.fight = fight_outcome
        self.flee = flee_outcome
    def fight():
        global correct_answer
        return correct_answer
    def flee():
        return exit()
class second_floor(room):
    def __init__(self, fight, flee):
        self.name = None
        self.fight = fight_outcome
        self.flee = flee_outcome
    def fight():
        return exit()
    def flee():
        return correct_answer
attic = room('die', 'die')

print """ You are in the basement of a tower, to escape you need to make it
to the to top floor, defeat the guards, and free the other prisoners.
At each level (basement,first floor, second floor, and attic) you will have to
choose whether to fight the guards, or try to evade them by fleeing.  Your 
decisions will determine the fate of you and the other prisoners"""


answer = raw_input ("What do you do? >")
if answer == "fight" or "flee":
    print "Good choice, you have moved to the first floor"
    next_room(first_floor)
else:
    print "You died"
    exit()
    
answer2 = raw_input ("What do you do? >")
if answer2 == 'fight':
    print "Good choice, you have moved to the second floor"
    next_room(second_floor)
else:
    print 'you died'
    exit()

answer3 = raw_input ("What do you do? >")
if answer3 == "flee":
    print 'Good choice, you have moved to the door of the attic'
    next_room(attic)
else:
    print "you died"
    exit()

attic = raw_input("There are six guards standing there, what do you do? >")
if attic == 'fight':
    print 'you were outnumbered, they easily overpowered you. \n you died'
elif attic == 'flee':
    print "the guards easily caught you. \n you died"
else:
    print "your indecision cost you your life"
exit()