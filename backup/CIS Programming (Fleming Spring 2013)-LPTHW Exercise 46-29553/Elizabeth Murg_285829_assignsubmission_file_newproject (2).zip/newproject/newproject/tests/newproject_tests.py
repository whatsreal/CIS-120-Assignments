#Elizabeth Murg
#Assignment Number 46. 2/24/2014.

from nose.tools import *
import NAME

def setup():
	print "SETUP!"
	
def teardown():
	print "TEAR DOWN!"
	
def test_basic():
	print "I RAN!"
	
	