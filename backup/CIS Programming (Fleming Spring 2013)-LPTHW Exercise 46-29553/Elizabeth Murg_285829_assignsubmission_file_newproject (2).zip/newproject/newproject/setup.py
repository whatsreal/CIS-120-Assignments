#Elizabeth Murg	
#Assignment Number 46. 2/24/2014

try:
	from setuptools import setup
except ImportError:
	from distutils.core import setup
	
config = { 
	'description': 'My Project',
	'author': 'Elizabeth Murg',
	'url': 'URL to get it at.',
	'download_url': 'Where to download it.',
	'author_email': 'elizabethmurg@gmail.com.',
	'version': '0.1',
	'install_requires': ['nose'],
	'packages': ['NAME'],
	'scripts': {'bin/myscript.py'},
	'name': 'projectname'
}

setup (**config)

