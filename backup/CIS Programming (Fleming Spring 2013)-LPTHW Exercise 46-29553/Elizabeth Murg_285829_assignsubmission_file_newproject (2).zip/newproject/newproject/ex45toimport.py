
from sys import exit
from random import randint


class Scene (object):
	def enter (self):
		print "This scene is not yet configured. Subclass it and implement enter. ()"
		

class Engine (object):
	def __init__ (self, scene_map):
		print "Engine __init__ has scene_map", scene_map
		self.scene_map = scene_map

	def play(self):
		current_scene = self.scene_map.opening_scene()
		print "Play's first scene", current_scene
		
		while True:
			print "\n ----------"
			next_scene_name = current_scene.enter()
			print "next scene", next_scene_name
			current_scene = self.scene_map.next_scene(next_scene_name)
			print "map returns new scene", current_scene
		

	
class Death (Scene):
	deathlines = [
		"Nice try...maybe next time?...Maybe....",
		"Ummm...you're not that great..not gonna lie.",
		"It's a good day to die...with you around.",
		"Yep. Game OVAAAAAAAA'."
	]
	def enter (self):
		print Death.deathlines [randint (0, len (self.deathlines) -1)]
		exit(1)

class ThroneRoom (Scene):
	def enter (self):
		print "Welcome to the Kingdom of Amaryllis. Your king's castle"
		print "was attacked by Lord Cumberland's Ruffians and the whole"
		print "place is in turmoil. The prince is hiding in his bedroom"
		print "and your task as the Lord Protector, is to rescue the poor"
		print "boy, wimp though he may be and take him to the fortress"
		print "3 miles away."
		print "You are in the throne room surrounded by masses of the"
		print "army of the great Lord Cumberland. They see you and pull"
		print "out their swords to kill you."
		
		whattodo = raw_input ("!!! ")
		
		if whattodo == "fight!":
			print "You bravely fight them but there are just too many!"
			print "The army amasses you on each flank and strikes heavy"
			print "blows. Eventually you tire out and are struck down."
			return 'death'
		elif whattodo == "run!":
			print "You look around madly in search of an escape. You see"
			print "a door in front of you and a door to your right. Which"
			print "do you choose?"
			
			action2 = raw_input ("!!! ")
			
			if action2 == "front":
				print "You make a dangerous dash through the masses for a large"
				print "oaken door. You reach it safely and slam it shut -- breathing"
				print "heavily. A cough startles you. Looking up you see -- the prince."
				return 'bed_room'
			elif action2 == "right door":
				print "To your right is a little door which you successfully reach"
				print "in no time. You rush through it and slam it shut, bolting it"
				print "into place."
				return 'g_s'
			else:
				print "THAT'S NOT AN OPTION!!!"
				return 'throne_room'
		else:
			print "THAT'S NOT AN OPTION!"
			return 'throne_room'
		
		
class GS (Scene):
	def enter (self):
		print "You have reached the Grand Staircase. You quickly scan the room for enemies,"
		print "but finding none, you look around for your options. You see a bucket of water"
		print "left carelessly by one of the maids, and decide to take it."
		print "North of you is a door, and east of you is a small barred gate."
		
		action3 = raw_input ("!!! ")
		
		if action3 == "take north door":
			print "You quietly open the north door and skulk through it."
			return 'ball_room'
		elif action3 == "take east door":
			print "You quietly open the east door and skulk through it."
			print "Taking the damp, musty steps leading downward you find"
			print "yourself in the castle jail."
			return 'jail_room'
		elif action3 == "throne room":
			return 'throne_room'
		else:
			print "THAT'S NOT AN OPTION RIGHT NOW!"
			return 'g_s'

class Ballroom (Scene):
	def enter (self):
		print "A disgusting hoarse laugh reaches your ears just as you close the door,"
		print "As you find that Lord Cumberland was waiting behind it."
		
		action10 = raw_input ("!!! ")
		
		if action10 == "fight":
			print "You pull out your sword just as he lifts his above his head."
			print "The battle is hard and bloody, but eventually you overcome him"
			print "and with one swift blow, his life is over."
			print "Breathing heavily you look around and see a door to your left"
			
			action11 = raw_input ("!!! ") 
			
			if action11 == "open door":
				print "Entering inside the room you discover it is the prince's bedroom."
				return 'bed_room2'
			else: 
				print "THAT'S NOT AN OPTION RIGHT NOW. GO FIND THE PRINCE!"

		else:
			print "That's not an option. Goodbye!"
			return 'ball_room'
class Bedroom2 (Scene):
	def enter (self):
		print "You grab the prince and escort him towards the ballroom door."
		
		action20 = raw_input ("!!! ")
		
		if action20 == "open door":
			return 'e_b'


class EB (Scene):    
    def enter (self):
		print "Looking around you see a door to your right, a door to your left,"
		print "a door in front of you, and a door behind."
		
		action8 = raw_input ("!!! ")
	
		if action8 == "right":
			print "You take the right door."
			return 'main_corridor'
		if action8 == "left":
			print "Umm... why would you go back to the bedroom?"
			print "Get yourself back to the ballroom and choose another door!"
			return 'e_b'
		
		if action8 == "front":
			print "At long last you reached the medium staircase which is the only way"
			print "to get to the kitchen. You breathe a deep sigh of relief."
			return 'medium_staircase'
		
		if action8 == "behind":
			print "You reach the grand staircase. If you have already been here, go back."
			print "If not, proceed."
			
			action123 = raw_input ("!!! ")
			
			if action123 == "go back":
				return 'e_b'
			if action123 == "proceed":
				return 'g_s'
			else:
				print "That's not an option."
				return 'e_b'
		else:
			print "That's not an option."
			return 'e_b'
		
		
class Bedroom (Scene):
	def enter (self):
		print "'Your majesty!' you cry out. You grab his hand and lead"
		print "him towards the planned escape door in the kitchen."
		print "There is a door behind you and a door to your right."
		print "What is your decision?"
		
		action4 = raw_input ("!!! ")
		
		if action4 == "behind":
			print "In a moment of panic, you lose your head and drag the king"
			print "back into the throne room. The malevolent forces of the great"
			print "Lord Cumberland scream with cruel joy as they throw themselves"
			print "upon the prince, killing both him and you within 3 minutes."
			return 'death'
		elif action4 == "right":
			print "Knowing that behind you lies the throne room full of evildoers,"
			print "you realize your only option is to go through the door to your"
			print "right, leading to the ballroom, and so you hesitantly open the door"
			print "And find yourself in the presence of the evil, terrible, Lord"
			print "Cumberland himself."
			return 'ball_room2'

class Ballroom2 (Scene):
	def enter (self):
		print "Lord Cumberland screams with rageful delight upon seeing you and the prince"
		print "He quickly draws his famous sword the Bloodbiter and advances at a maddening"
		print "speed. You ungracefully, but understandably, shove the prince behind you and..."
		
		action7 = raw_input ("!!! ")
		
		if action7 == "fight":
			print "It is a fight to the death without a doubt. You fight for what seems like hours"
			print "and ultimately defeat the evil man, but lose a pinky in the process."
			print "Grabbing the prince you make a dash for one of the doors (one in front, one to your right)."
			
			action32 = raw_input ("!!! ")
			
			if action32 == "front":
				print "Rushing to the door in front of you, you find yourself in the medium staircase."
				return 'medium_staircase'
			elif action32 == "right":
				print "You quickly bolt through the door to your right, and find yourself in the main corridor."
				return 'main_corridor'
			else:
				print "That's not an option, human."
				return 'ball_room2'
				
		
class Jail (Scene):
	def enter (self):
		print "The jail is horrid and smells of unwashed human and thickened blood"
		print "You shudder at the sights and smells that you behold, but press onward"
		print "hoping against all hope that somehow you will find something that will help"
		print "you in your mission."
		print "Turning a corner, you hear a cackle." 
		
		action5 = raw_input ("!!! ")
		
		if action5 == "go forward":
			print "Hesitantly you continue onward, and suddenly you come face to face with the"
			print "evil Lady Merlot, infamous accomplice of the great Lord Cumberland. She cackles"
			print "as she begins reciting her sorcery and enchantments. Seeking to enslave you in the"
			print "dungeons for all eternity."
			
			action6 = raw_input ("!!! ")
			
			if action6 == "throw bucket of water":
				print "You decide enough is enough. Lifting up the heavy bucket, you splash it all over"
				print "her and watch in amazement as she melts away, shrieking the entire time. Finally"
				print "you sprint up the stairs."
				return 'g_s'
			else:
				print "Lady Merlot continues to cackle evilly as she sees her plan is working."
				print "You eventually lose all control over yourself and scream with hopelessness."
				return 'death'
		elif action5 == "turn back": 
			return 'g_s'
			
		else:
			print "That's not an option."
			return 'g_s'
		

class MainCorridor (Scene):
	def enter (self):
		print "The main corridor is completely empty but you quickly see that someone has left"
		print "A bow and some poisoned arrows  lying around."
		
		action11 = raw_input ("!!! ")
		
		if action11 == "take bow and arrows":
			print "You grab the weapons and see a door ahead of you"
			
			action12 = raw_input ("!!! ")
			
			if action12 == "open door":
				print "Opening the door you find yourself at the bottom of the stairs leading to the tower."
				print "You know it is probably a waste of time and energy to go up. You..."
		
		
				action13 = raw_input ("!!! ")
				
				if action13 == "go up":
					print "You foolishly decide to make the trek anyway"
					print "An hour later when you finally make it to the top"
					print "You come face to face with the deadly dragon that"
					print "was rumored to inhabit these walls."
					
					action14 = raw_input ("!!! ") 
					
					if action14 == "shoot dragon":
						print "Luckily you have your poisoned arrows on hand."
						print "You shoot the dragon and quickly run back down"
						print "and out of the main corridor into the ballroom."
						return 'e_b'
					else:
						print "The dragon roars with rage and kills you. Basically"
						print "you kinda asked for it...not gonna lie."
						return 'death'
				elif action13 == "go back": 
					return 'main_corridor'
				else:
					print "THAT's NOT AN OPTION RIGHT NOW."
					return 'main_corridor'
			else: 
				print "THAT'S NOT AN OPTION RIGHT NOW."
				return 'main_corridor'
						
		elif action11 == "go back":
			return 'e_b'
		
		else:
			print "THAT'S NOT AN OPTION RIGHT NOW."
			
					
class MediumStaircase (Scene):
	def enter (self):
		print "Looking around you see a door to your left." 
		
		action14 = raw_input ("!!! ")
			
		if action14 == "open door":
			print "You find yourself in the kitchen."
			return 'kit_chen'
		elif action14 == "go back":
			return 'e_b'
			
		else:
			print "THAT'S NOT AN OPTION!"
			return 'medium_staircase'
		
		
		
class Kitchen (Scene):
	def enter (self): 
		print "Finally, you reach the kitchen. This is the only way to the"
		print "fortress. However, your challenges are not over."
		print "To get to the fortress you must defeat the fire-breathing apes"
		print "which have taken over the kitchen."
		
		action15 = raw_input ("!!! ")
		
		if action15 == "feed apes":
			print "Ummm the apes were IN THE KITCHEN....Why would you feed them?"
			print "What do you think they were doing in the kitchen..."
			return 'death'
		
		elif action15 == "fight":
			print "You fight long and hard, but the apes overpower you with their flames"
			print "But wait! You make a surprising comeback and finally you defeat the apes"
			print "and run away HOME FREE!"
			print "YOU WINNNNNNN!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
			exit (0)
		elif action15 == "befriend apes":
			print "ONE DOES NOT SIMPLY BEFRIEND FIRE-BREATHING APES!"
			return 'death'
		elif action15 == "tell a joke":
			print "Fire-breathing apes have no sense of humor."
			return 'death'
		elif action15 == "run":
			print "You sprint towards the door and thrust the prince through"
			print "it. 'RUN!' you say, then turn to face your death."
			return 'death'
		else:
			print "The monkeys don't think that's a good choice, so they kill you. Goodbye."
			return 'death'
		
class Map (object):

	scenes = {
		'throne_room': ThroneRoom(),
		'g_s': GS(),
		'bed_room': Bedroom(),
		'bed_room2': Bedroom2(),
		'e_b': EB(),
		'main_corridor' : MainCorridor(),
		'ball_room': Ballroom(),
		'kit_chen': Kitchen(),
		'jail_room': Jail(),
		'medium_staircase': MediumStaircase (),
		'ball_room2': Ballroom2 (),
		'death': Death()
	}
		
	def __init__ (self, start_scene):
		self.start_scene = start_scene
		print "start_scene in __init__", self.start_scene
	def next_scene (self, scene_name):
		print "start_scene in next_scene"
		val = Map.scenes.get(scene_name)
		print "next_scene returns", val
		return val
	def opening_scene(self):
		return self.next_scene(self.start_scene)
		

		
		

			
a_map = Map('throne_room')
a_game = Engine(a_map)
a_game.play()